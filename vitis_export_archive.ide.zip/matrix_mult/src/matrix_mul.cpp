
extern "C"{
#include <matrix_mul.h>
void matrix_mul (const int * A, //read only A NxM
				const  int * B, //read only B MxP
				int *C){	// write  C NxP matrix

#pragma HLS INTERFACE m_axi port = A offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = B offset = slave bundle = gmem
#pragma HLS INTERFACE m_axi port = C offset = slave bundle = gmem

#pragma HLS INTERFACE s_axilite port = A bundle = control
#pragma HLS INTERFACE s_axilite port = B bundle = control
#pragma HLS INTERFACE s_axilite port = C bundle = control
#pragma HLS INTERFACE s_axilite port = return bundle = control

	int A_buffer[n*m];   // Local memory to store A
	int B_buffer[m*p];   // Local memory to store B
	int C_buffer[n*p]; // Local Memory to store result
	int SIZE = n*m;
	readA: for(int i = 0; i < n; i++){
	  for (int j = 0; j < m; j++) {
	#pragma HLS LOOP_TRIPCOUNT min = SIZE max = SIZE
	#pragma HLS PIPELINE II = 1
		  A_buffer[i*n+j] = A[i*n+j];
	    }
	 }

	readB: for(int i = 0; i < m; i++){
	  for (int j = 0; j < p; j++) {
	#pragma HLS LOOP_TRIPCOUNT min = SIZE max = SIZE
	#pragma HLS PIPELINE II = 1
		  B_buffer[i*m+j] = B[i*m+j];
	    }
	 }
	fill_C_with_zeros:for(int i = 0; i < n; i++){
		  for (int j = 0; j < p; j++) {
			  C_buffer[i*n +j] =0;
		  }
	}


//#pragma HLS ARRAY_RESHAPE varable=A complete dim=2
//#pragma HLS ARRAY_RESHAPE varable=B complete dim=1 //reduce the numeber of control logic's vs using ARRAY_PARITIONS
	mult:for(int i = 0; i< n; i++){
		for(int j = 0; j < p; j++){
#pragma HLS PIPELINE II=1
			int results =0;
			product: for(int k = 0; k < m; k++){
				results += A_buffer[i *n + k] * B_buffer[k * m + j];
			}
			 C[i*n+j] = results;
		}
	}

}
}
