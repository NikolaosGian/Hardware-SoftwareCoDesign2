#ifndef MATR_MUL_TB_H
#define MATR_MUL_TB_H

#define lm 4
#define ln 4
#define lp 4

#define m (1 << lm)
#define n (1 << ln)
#define p (1 << lp)

#endif
